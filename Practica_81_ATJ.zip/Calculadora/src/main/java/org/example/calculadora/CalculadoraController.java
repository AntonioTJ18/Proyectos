package org.example.calculadora;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.control.TextFormatter;

import java.net.URL;
import java.util.ResourceBundle;

public class CalculadoraController implements Initializable {
    @FXML
    private TextField display;
    @FXML
    ListView<String> lv_historial = new ListView<>();

    private double num1 = 0, num2 = 0, result = 0;
    private String operator = "";
    private CalculadoraDAO dao;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        //no permite que se inserten caracteres que no sean numeros
//        configuracionValidacion();

        ObservableList<String> items = FXCollections.observableArrayList(dao.mostrarHistorial());
        lv_historial.setItems(items);
    }

//    private void configuracionValidacion() {
//        display.setTextFormatter(new TextFormatter<>(change -> {
//            String texto = change.getControlNewText();
//            if (texto.isEmpty()) {
//                return change;
//            }
//
//            if (texto.matches("\\d*")) {
//                return change;
//            }
//
//            return null;
//        }));
//
//    }

    public CalculadoraController() {
        dao = new CalculadoraDAO();
    }

    @FXML
    private void handleButtonAction(ActionEvent event) {
        String value = ((Button)event.getSource()).getText();

        switch (value) {
            case "+":
            case "-":
            case "*":
            case "/":
                operator = value;
                num1 = Double.parseDouble(display.getText());
                display.clear();
                break;
            case "=":
                num2 = Double.parseDouble(display.getText());
                result = calculateResult();
                display.setText(String.valueOf(result));
                dao.saveOperation(num1 + " " + operator + " " + num2 + " = " + result);
                break;
            case "C":
                result = 0;
                display.clear();
                dao.saveOperation(String.valueOf(result));
                break;
            default:
                if(!value.equals("C")) {
                    display.setText(display.getText() + value);
                }
        }
    }

    private double calculateResult() {
        switch (operator) {
            case "+":
                return num1 + num2;
            case "-":
                return num1 - num2;
            case "*":
                return num1 * num2;
            case "/":
                return num1 / num2;
            default:
                return 0;
        }
    }

    //[Prueba de estres]
    public void pruebaEstres() {
        for (int i = 0; i < 1000; i++) {
            num1 = i;
            num2 = i + 1;
            operator = "+";
            result = calculateResult();
            dao.saveOperation(num1 + " " + operator + " " + num2 + " = " + result);
        }
        System.out.println("1000 operaciones realizadas");
    }

}