package org.example.calculadora;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.util.Objects;

public class CalculadoraApp extends Application {
    @Override
    public void start(Stage primaryStage) throws Exception {
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("Calculadora.fxml")));
        primaryStage.setTitle("Calculadora JavaFX");
        primaryStage.setScene(new Scene(root, 450, 250));
        primaryStage.show();
    }

    public static void main(String[] args) {
//        new CalculadoraDAO().pruebaVolumen();
//            CalculadoraController pruebaEstres = new CalculadoraController();
//            pruebaEstres.pruebaEstres();
        launch(args);
    }
}



