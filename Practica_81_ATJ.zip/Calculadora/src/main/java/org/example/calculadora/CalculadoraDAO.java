package org.example.calculadora;

import java.sql.*;
import java.util.ArrayList;

public class CalculadoraDAO {
    private Connection conn;

    public CalculadoraDAO() {
        try {
            conn = DriverManager.getConnection("jdbc:sqlite:src/main/resources/BD/CalculadoraBD.db");
            Statement stmt = conn.createStatement();
            stmt.execute("CREATE TABLE IF NOT EXISTS historial (operacion TEXT)");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void saveOperation(String operation) {
        try {
            PreparedStatement pstmt = conn.prepareStatement("INSERT INTO historial(operacion) VALUES(?)");
            pstmt.setString(1, operation);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public ArrayList<String> mostrarHistorial(){
        ArrayList<String> historial = new ArrayList<>();
        try{
            PreparedStatement pstmt = conn.prepareStatement("SELECT * FROM historial");
            ResultSet rs = pstmt.executeQuery();
            while(rs.next()){
                historial.add(rs.getString(1));
            }
            rs.close();
            pstmt.close();
        }catch(SQLException e){
            e.printStackTrace();
        }
        return historial;
    }

    //[Prueba de volumen]metodo para insertar 5000 registros
    public void pruebaVolumen() {
        try {
            PreparedStatement pstmt = conn.prepareStatement("INSERT INTO historial(operacion) VALUES(?)");

            for (int i = 0; i < 5000; i++) {
                pstmt.setString(1, "Prueba nº:" + i);
                pstmt.executeUpdate();
            }

            ResultSet rs = conn.createStatement().executeQuery("SELECT COUNT(*) FROM historial");
            System.out.println("Registros insertados: " + rs.getInt(1));

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
