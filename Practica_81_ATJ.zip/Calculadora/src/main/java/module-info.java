module org.example.calculadora {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires javafx.base;
    requires javafx.graphics;

    opens org.example.calculadora to javafx.fxml, javafx.graphics;
    exports org.example.calculadora;
}