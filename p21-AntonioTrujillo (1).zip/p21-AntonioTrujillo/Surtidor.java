public class Surtidor {

    private int bidonesDisponibles;
    private final int capacidadMaxima = 3;

    public Surtidor(){
        bidonesDisponibles = 0;
    }

    public void prepararBidon(String nombreMecanico){
        
        synchronized(this){
            while (bidonesDisponibles == capacidadMaxima) { // Chequeo de que los bidones no superen el maximo permitido
                try {
                    wait();
                } catch (InterruptedException e) {
                    e.getStackTrace();
                    }
                }

            bidonesDisponibles++; // Incrementacion de los bidones si se cumple la condicion anterior
            System.out.println("Mecánico " + nombreMecanico  + " añade bidón. Total: " + bidonesDisponibles);
            notifyAll();
        }
        
        
    }

    public void repostar(String nombreCoche){

        synchronized(this){
            while (bidonesDisponibles == 0) { // Chequeo de que los bidones no superen el maximo permitido
                try {
                    wait();
                } catch (InterruptedException e) {
                    e.getStackTrace();
                }
                }
            bidonesDisponibles--; // Decrementa de los bidones si se cumple la condicion anterior
            System.out.println("El coche " + nombreCoche  + " ha repostado. Quedan: " + bidonesDisponibles);
            notifyAll(); // Despertamos todos los hilos
        }
    }
    
}