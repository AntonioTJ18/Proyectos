import java.util.ArrayList;
import java.util.List;

public class MainSurtidor {

    public static void main(String[] args) {
        Surtidor surtidor = new Surtidor();
        Object semaforo  = new Object();
        List<String> podio = new ArrayList<>();
        
        int contador = 1;

        Runnable tarea_mecanico = () -> { // Tarea que ejecuta los metodos para el mecanico y retardo de espera
            for (int i = 0; i < 10; i++) {
                surtidor.prepararBidon(Thread.currentThread().getName()); 
                try {
                    Thread.sleep(((int)(Math.random()) * 300) + 100 );
                } catch (InterruptedException e) {
                    e.getStackTrace();
                }
            }
        };


        Runnable tarea_coche = () -> { // Tarea que ejecuta los metodos para el coche y retardo de espera
            synchronized(semaforo){
                
                try {
                    semaforo.wait(2000);
                } catch (InterruptedException e) {
                    e.getStackTrace();
                }
                
                for (int i = 0; i < 5; i++) {
                    surtidor.repostar(Thread.currentThread().getName());

                    try {
                        Thread.sleep(((int)(Math.random()) * 500) + 300 );
                    } catch (InterruptedException e) {
                        e.getStackTrace();
                    }
                }
                podio.add(Thread.currentThread().getName());

            }
        };
        // Creacion de hilos mecanicos y coches
        Thread hiloMecanico1 = new Thread(tarea_mecanico, "Manolo");
        Thread hiloMecanico2 = new Thread(tarea_mecanico, "Benito");
        
        Thread hiloCoche1 = new Thread(tarea_coche, "Ferrari");
        Thread hiloCoche2 = new Thread(tarea_coche, "Red Bull");
        Thread hiloCoche3 = new Thread(tarea_coche, "Mercedes");

        // Espera para que todos comiencen a la vez
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.getStackTrace();
        }

        System.out.println("¡Semáforo en verde, arranca la carrera!");
        synchronized(semaforo){
            hiloCoche1.start();
            hiloCoche2.start();
            hiloCoche3.start();
            
        }

        hiloMecanico1.start();
        hiloMecanico2.start();
        
        
        // Join para que salga el mensaje del podio
        try {
            hiloCoche1.join();
            hiloCoche2.join();
            hiloCoche3.join();
        } catch (InterruptedException e) {
            e.getStackTrace();
        }

        for (String coche : podio) {
            System.out.println("Puesto " + contador + "º" + " " + coche);
            contador++;
            
        }

        
        


    }

    
    
} 